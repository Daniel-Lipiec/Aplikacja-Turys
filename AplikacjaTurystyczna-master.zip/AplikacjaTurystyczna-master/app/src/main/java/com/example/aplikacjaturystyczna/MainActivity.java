package com.example.aplikacjaturystyczna;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseAuthRecentLoginRequiredException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button1 = findViewById(R.id.button17);
        Button button2 = findViewById(R.id.button18);

        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
                case R.id.button17:
                    startActivity(new Intent(this, Logowanie.class));
                    break;
            case R.id.button18:
                startActivity(new Intent(this, Rejestracja.class));
                break;
        }
    }


    public static String getMyLocalizedMessage(Exception e) {
        String returnResult = "Wystąpił błąd :(";
        if (e instanceof FirebaseAuthInvalidUserException) {
            returnResult = "W bazie danych nie istnieje użytkownik o podanym adresie email lub konto zostało zablokowane.";
        } else if (e instanceof FirebaseAuthUserCollisionException) {
            returnResult = "Podany adres email jest już używany!";
        } else if (e instanceof FirebaseAuthWeakPasswordException) {
            returnResult = "Wprowadzone hasło jest zbyt słabe.";
        } else if (e instanceof FirebaseAuthRecentLoginRequiredException) {
            returnResult = "Twoja sesja logowania trwa zbyt długo, prosimy Cię o podanie hasła do Twojego konta.";
        } else if (e instanceof FirebaseTooManyRequestsException) {
            returnResult = "Zbyt wiele prób połączenia... odczekaj chwilę!";
        } else if (e instanceof FirebaseAuthInvalidCredentialsException) {
            returnResult = "Wprowadzone dane logowania się nie zgadzają.";
        }
        return returnResult;
    }
}