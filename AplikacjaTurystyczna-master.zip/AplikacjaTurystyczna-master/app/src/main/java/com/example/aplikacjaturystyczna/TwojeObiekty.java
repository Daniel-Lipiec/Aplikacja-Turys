package com.example.aplikacjaturystyczna;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.aplikacjaturystyczna.klasy.Obiekt;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

public class TwojeObiekty extends AppCompatActivity {

    private RecyclerView recyclerView_TwojeObiekty;
    private AdapterTwojeObiekty adapterTwojeObiekty;
    private ProgressBar progressBar;
    private TextView textView_brakObiektow;
    private Button button_wyznaczTrase, button_zapiszTrase;
    public static ArrayList<Obiekt> listaObiektow;
    private final FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    public static String DB_NAME="AplikacjaTurystyczna";
    public static String TRASA_COUNT_KEY ="TRASA_COUNT_KEY";
    private int trasaCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_twoje_obiekty);

        textView_brakObiektow = findViewById(R.id.textView_brakObiektow);
        progressBar = findViewById(R.id.progressBar);
        recyclerView_TwojeObiekty = findViewById(R.id.recyclerView_TwojeObiekty);
        listaObiektow = new ArrayList<>();
        button_wyznaczTrase=findViewById(R.id.button_wyznaczTrase);
        button_zapiszTrase=findViewById(R.id.button_ZapiszTrase);
        preferences=getSharedPreferences(DB_NAME,MODE_PRIVATE);
        editor=preferences.edit();

        trasaCount=preferences.getInt(TRASA_COUNT_KEY,1);
        //WYŚWIETLANIE OBIEKTÓW W GOOGLE MAPS
        button_wyznaczTrase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(listaObiektow.size()>0) {

                    String url ="google.navigation:q=" +listaObiektow.get(0).getNazwa() + " " + listaObiektow.get(0).getAdres();


                    if (listaObiektow.size() > 1) {

                        url+="&waypoints="+ listaObiektow.get(1).getNazwa() + " " + listaObiektow.get(1).getAdres()+"|";
                        if(listaObiektow.size()>2) {
                            for (int i = 2; i < listaObiektow.size(); i++) {
                                url+=listaObiektow.get(i).getNazwa() + " " + listaObiektow.get(i).getAdres() + "|";
                            }

                        }
                        url = url.substring(0, url.length() - 1);

                    }

                    //Uri gmmIntentUri = Uri.parse(url);
                    Log.i("test1", "onClick: "+url);
                    Uri gmmIntentUri = Uri.parse(url);

                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    startActivity(mapIntent);
                }
                else{
                    Toast.makeText(TwojeObiekty.this, "brak obiektów", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //ZAIS TRASY
        button_zapiszTrase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putString("trasa"+trasaCount, new Gson().toJson(listaObiektow));
                editor.putInt(TRASA_COUNT_KEY,trasaCount+1);
                editor.apply();
                trasaCount++;
                Toast.makeText(TwojeObiekty.this, "Trasa zapisana", Toast.LENGTH_SHORT).show();
            }
        });



        // POBIERANIE OBIEKTÓW
        Query obiektyBazaDanych = firebaseDatabase.getReference().child("obiekty");
        obiektyBazaDanych.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull final DataSnapshot postsSnapshot) {

                for (DataSnapshot data : postsSnapshot.getChildren()) {
                    Obiekt obiekt = new Obiekt();

                    obiekt.setAdres(String.valueOf(data.child("adres").getValue()));
                    obiekt.setNazwa(String.valueOf(data.child("nazwa").getValue()));
                    obiekt.setOpis(String.valueOf(data.child("opis").getValue()));
                    obiekt.setId(data.getKey());

                    for (DataSnapshot user : data.child("uzytkownicy").getChildren()) {
                        if (user.getKey().equalsIgnoreCase(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
                            listaObiektow.add(obiekt);
                        }
                    }
                }

                progressBar.setVisibility(View.GONE);

                // JESLI LISTA JEST PUSTA
                if (listaObiektow.size() == 0) {
                    textView_brakObiektow.setVisibility(View.VISIBLE);
                    return;
                }

                LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
                recyclerView_TwojeObiekty.setLayoutManager(layoutManager);
                adapterTwojeObiekty = new AdapterTwojeObiekty(getApplicationContext(), listaObiektow);
                recyclerView_TwojeObiekty.setAdapter(adapterTwojeObiekty);

                button_wyznaczTrase.setEnabled(true);
                button_zapiszTrase.setEnabled(true);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    // WYSWIETLANIE OBIEKTOW NA LISCIE
    public static class AdapterTwojeObiekty extends RecyclerView.Adapter<AdapterTwojeObiekty.ViewHolder> {

        private final Context mContext;
        private final List<Obiekt> listaObiektow;

        public AdapterTwojeObiekty(Context context, List<Obiekt> listaObiektow) {
            mContext = context;
            this.listaObiektow = listaObiektow;
        }

        @NonNull
        @Override
        public AdapterTwojeObiekty.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.jedenobiekt_twojalista, parent, false);
            return new AdapterTwojeObiekty.ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final AdapterTwojeObiekty.ViewHolder holder, final int position) {

            holder.textView_nazwa.setText(listaObiektow.get(position).getNazwa());
            holder.textView_adres.setText(listaObiektow.get(position).getAdres());

            holder.imageView_usun.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    FirebaseDatabase.getInstance().getReference("obiekty").child(listaObiektow.get(position).getId()).child("uzytkownicy").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(null);
                    Toast.makeText(mContext, "Usunieto!", Toast.LENGTH_SHORT).show();
                    listaObiektow.remove(position);
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, listaObiektow.size());
                }
            });

        }

        @Override
        public int getItemCount() {
            return listaObiektow.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            TextView textView_nazwa;
            TextView textView_adres;
            ImageView imageView_usun;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                imageView_usun = itemView.findViewById(R.id.imageView_usun);
                textView_nazwa = itemView.findViewById(R.id.textView_nazwa);
                textView_adres = itemView.findViewById(R.id.textView_adres);
            }

        }
    }
}