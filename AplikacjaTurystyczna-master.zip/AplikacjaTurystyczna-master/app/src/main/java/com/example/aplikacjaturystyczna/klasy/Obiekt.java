package com.example.aplikacjaturystyczna.klasy;

import java.util.List;

public class Obiekt {

    private String id;
    private String nazwa;
    private String adres;
    private String opis;
    private List<String> uzytkownicy;

    public List<String> getUzytkownicy() {
        return uzytkownicy;
    }

    public void setUzytkownicy(List<String> uzytkownicy) {
        this.uzytkownicy = uzytkownicy;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public String getAdres() {
        return adres;
    }

    public void setAdres(String adres) {
        this.adres = adres;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }
}
