package com.example.aplikacjaturystyczna;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.aplikacjaturystyczna.klasy.Obiekt;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.example.aplikacjaturystyczna.TwojeObiekty.DB_NAME;
import static com.example.aplikacjaturystyczna.TwojeObiekty.TRASA_COUNT_KEY;

public class TwojeTrasy extends AppCompatActivity {

    public static SharedPreferences preferences;
    public static SharedPreferences.Editor editor;
    private RecyclerView recyclerView_TwojeTrasy;
    private AdapterTwojeTrasy adapterTwojeTrasy;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_twoje_trasy);
        preferences=getSharedPreferences(DB_NAME,MODE_PRIVATE);
        editor=preferences.edit();
        recyclerView_TwojeTrasy=findViewById(R.id.recyclerView_TwojeTrasy);

        recyclerView_TwojeTrasy.setLayoutManager(new LinearLayoutManager(this));
        int trasaCount = preferences.getInt(TRASA_COUNT_KEY, 1);
        adapterTwojeTrasy = new AdapterTwojeTrasy(getApplicationContext(), trasaCount-1);
        recyclerView_TwojeTrasy.setAdapter(adapterTwojeTrasy);


    }

    // WYSWIETLANIE OBIEKTOW NA LISCIE
    public static class AdapterTwojeTrasy extends RecyclerView.Adapter<TwojeTrasy.AdapterTwojeTrasy.ViewHolder> {

        private final Context mContext;
        private int trasaCount;

        public AdapterTwojeTrasy(Context context, int trasaCount) {
            mContext = context;
            this.trasaCount = trasaCount;
        }

        @NonNull
        @Override
        public TwojeTrasy.AdapterTwojeTrasy.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.jedenobiekt_twojalista2, parent, false);
            return new TwojeTrasy.AdapterTwojeTrasy.ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final TwojeTrasy.AdapterTwojeTrasy.ViewHolder holder, final int position) {

            holder.textView_nazwa.setText("trasa "+(position+1));
            holder.layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String json=preferences.getString("trasa"+(position+1),"");
                    Log.i("testclick", "onClick: "+json);
                    Gson gson=new Gson();
                    List<Obiekt> listaObiektow = Arrays.asList(gson.fromJson(json, Obiekt[].class));
                    if(listaObiektow.size()>0) {

                        String url ="google.navigation:q=" +listaObiektow.get(0).getNazwa() + " " + listaObiektow.get(0).getAdres();


                        if (listaObiektow.size() > 1) {

                            url+="&waypoints="+ listaObiektow.get(1).getNazwa() + " " + listaObiektow.get(1).getAdres()+"|";
                            if(listaObiektow.size()>2) {
                                for (int i = 2; i < listaObiektow.size(); i++) {
                                    url+=listaObiektow.get(i).getNazwa() + " " + listaObiektow.get(i).getAdres() + "|";
                                }

                            }
                            url = url.substring(0, url.length() - 1);

                        }

                        //Uri gmmIntentUri = Uri.parse(url);
                        Log.i("test1", "onClick: "+url);
                        Uri gmmIntentUri = Uri.parse(url);

                        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                        mapIntent.setPackage("com.google.android.apps.maps");
                        mapIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        mContext.startActivity(mapIntent);
                    }
                }
            });

            holder.imageView_usun.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(mContext, "Usunieto!", Toast.LENGTH_SHORT).show();
                    for (int i=position;i<trasaCount;i++) {
                        editor.putString("trasa" + (position + i), preferences.getString("trasa" + (position + (i + 1)), ""));

                    }
                    editor.putInt(TRASA_COUNT_KEY, trasaCount);
                    editor.apply();

                    notifyItemRemoved(position);

                    trasaCount--;
                    notifyDataSetChanged();

                }
            });

        }

        @Override
        public int getItemCount() {

            return trasaCount;
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            TextView textView_nazwa;
            ImageView imageView_usun;
            RelativeLayout layout;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                textView_nazwa = itemView.findViewById(R.id.textView_nazwa);
                imageView_usun = itemView.findViewById(R.id.imageView_usun);
                layout = itemView.findViewById(R.id.layoutListElement);


            }

        }
    }



}