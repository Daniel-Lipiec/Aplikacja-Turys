package com.example.aplikacjaturystyczna;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.aplikacjaturystyczna.klasy.Obiekt;
import com.google.firebase.auth.FirebaseAuth;

public class Menu extends AppCompatActivity {

    Button button_logout;
    Button button_obiekty;
    Button button_zapiszObiektyDoListy;
    Button button_zapisaneTrasy;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        mAuth = FirebaseAuth.getInstance();

        button_obiekty = findViewById(R.id.button_obiekty);
        button_obiekty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Obiekty.class));
            }
        });

        button_zapiszObiektyDoListy = findViewById(R.id.button_zapiszObiektyDoListy);
        button_zapiszObiektyDoListy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), TwojeObiekty.class));
            }
        });


        button_logout = findViewById(R.id.button_logout);
        button_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mAuth.signOut();
                finish();
                Toast.makeText(getApplicationContext(), R.string.logout_text, Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });

        button_zapisaneTrasy=findViewById(R.id.button_trasy);
        button_zapisaneTrasy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), TwojeTrasy.class));
            }
        });
    }
}