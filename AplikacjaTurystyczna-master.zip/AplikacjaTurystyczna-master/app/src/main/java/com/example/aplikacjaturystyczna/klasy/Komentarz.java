package com.example.aplikacjaturystyczna.klasy;

public class Komentarz {

    private String id;
    private String id_obiektu;
    private String komentarz;
    private String autor;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId_obiektu() {
        return id_obiektu;
    }

    public void setId_obiektu(String id_obiektu) {
        this.id_obiektu = id_obiektu;
    }

    public String getKomentarz() {
        return komentarz;
    }

    public void setKomentarz(String komentarz) {
        this.komentarz = komentarz;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }
}
