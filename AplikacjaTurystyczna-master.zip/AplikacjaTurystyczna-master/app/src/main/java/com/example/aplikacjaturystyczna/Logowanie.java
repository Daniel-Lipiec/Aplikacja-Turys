package com.example.aplikacjaturystyczna;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class Logowanie extends AppCompatActivity {


    EditText textbox_login;
    EditText password_textbox;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);
        mAuth = FirebaseAuth.getInstance();

        textbox_login = findViewById(R.id.editTextTextEmailAddress);
        password_textbox = findViewById(R.id.editTextTextPassword);

        Button button1 = findViewById(R.id.button15);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email = textbox_login.getText().toString();
                String password = password_textbox.getText().toString();

                // Sprawdzanie czy to MAIL
                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    Toast.makeText(getApplicationContext(), R.string.wrong_email_format, Toast.LENGTH_SHORT).show();
                    return;
                }

                // Sprawdzanie czy hasło nie jest puste
                if (password_textbox.length() == 0) {
                    Toast.makeText(getApplicationContext(), R.string.empty_field, Toast.LENGTH_SHORT).show();
                    return;
                }

                // Logowanie
                mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), R.string.successfull_logged, Toast.LENGTH_SHORT).show();
                            finish();
                            startActivity(new Intent(getApplicationContext(), Menu.class));
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("TAGA", e.toString());
                        Toast.makeText(getApplicationContext(), MainActivity.getMyLocalizedMessage(e), Toast.LENGTH_SHORT).show();
                    }
                });


            }
        });
    }

}
