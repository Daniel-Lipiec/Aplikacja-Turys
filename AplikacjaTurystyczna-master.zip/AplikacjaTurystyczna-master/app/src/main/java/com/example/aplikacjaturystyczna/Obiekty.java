package com.example.aplikacjaturystyczna;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.aplikacjaturystyczna.klasy.Obiekt;
import com.github.aakira.expandablelayout.ExpandableRelativeLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Obiekty extends AppCompatActivity {

    private RecyclerView recyclerView_obiekty;
    private SearchView searchView_obiekty;
    private TextView textView_brakObiektow;
    private ProgressBar progressBar;
    private Button button_zapiszObiektyDoListy;
    private AdapterObiektow adapterObiektow;
    private ArrayList<Obiekt> listaZaznaczonychObiektow;
    public static ArrayList<Obiekt> listaObiektow;
    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_obiekty);

        textView_brakObiektow = findViewById(R.id.textView_brakObiektow);
        textView_brakObiektow.setText("Wprowadź w wyszukiwarkę nazwę interesującego Cię miasta!");
        progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(View.INVISIBLE);
        recyclerView_obiekty = findViewById(R.id.recyclerView_obiekty);
        searchView_obiekty = findViewById(R.id.searchView_obiekty);
        button_zapiszObiektyDoListy = findViewById(R.id.button_zapiszObiektyDoListy);
        listaObiektow = new ArrayList<>();

        // DODAWANIE
        listaZaznaczonychObiektow = new ArrayList<>();
        button_zapiszObiektyDoListy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listaZaznaczonychObiektow.size() == 0) {
                    Toast.makeText(Obiekty.this, "Nie zaznaczono żadnych nowych obiektów!", Toast.LENGTH_SHORT).show();
                    return;
                }

                for (Obiekt obiekt : listaZaznaczonychObiektow) {
                    firebaseDatabase.getReference("obiekty").child(obiekt.getId()).child("uzytkownicy").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue("true");
                    Toast.makeText(Obiekty.this, "Zapisano pomyślnie!", Toast.LENGTH_SHORT).show();
                }
            }
        });


        // POBIERANIE OBIEKTÓW
        searchView_obiekty.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                if (s.length() < 3) {
                    textView_brakObiektow.setText("Wprowadź w wyszukiwarkę nazwę interesującego Cię miasta!");
                    textView_brakObiektow.setVisibility(View.VISIBLE);
                    listaObiektow.clear();
                    if (adapterObiektow != null) {
                        adapterObiektow.notifyDataSetChanged();
                    }
                } else {

                    listaObiektow.clear();
                    progressBar.setVisibility(View.VISIBLE);
                    textView_brakObiektow.setVisibility(View.INVISIBLE);
                    Query obiektyBazaDanych = firebaseDatabase.getReference().child("obiekty").orderByChild("adres").startAt(s).endAt(s + "\uf8ff");
                    obiektyBazaDanych.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull final DataSnapshot postsSnapshot) {

                            for (DataSnapshot data : postsSnapshot.getChildren()) {
                                Obiekt obiekt = new Obiekt();

                                obiekt.setAdres(String.valueOf(data.child("adres").getValue()));
                                obiekt.setNazwa(String.valueOf(data.child("nazwa").getValue()));
                                obiekt.setOpis(String.valueOf(data.child("opis").getValue()));
                                obiekt.setId(data.getKey());

                                // POBIERANIE LISTY UZYTKOWNIKOW
                                List<String> listaUzytkownikow = new ArrayList<>();
                                for (DataSnapshot user : data.child("uzytkownicy").getChildren()) {
                                    listaUzytkownikow.add(String.valueOf(user.getKey()));
                                }
                                obiekt.setUzytkownicy(listaUzytkownikow);
                                listaObiektow.add(obiekt);
                            }

                            progressBar.setVisibility(View.GONE);

                            // JESLI LISTA JEST PUSTA
                            if (listaObiektow.size() == 0) {
                                textView_brakObiektow.setVisibility(View.VISIBLE);
                                textView_brakObiektow.setText("Nie znaleźliśmy w bazie obiektów, które znajdują się w tym kraju.");
                                return;
                            }

                            LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
                            recyclerView_obiekty.setLayoutManager(layoutManager);
                            adapterObiektow = new AdapterObiektow(getApplicationContext(), listaObiektow);
                            recyclerView_obiekty.setAdapter(adapterObiektow);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }
                return false;
            }
        });
    }


    // WYSWIETLANIE OBIEKTOW NA LISCIE
    public class AdapterObiektow extends RecyclerView.Adapter<AdapterObiektow.ViewHolder> {

        private List<Obiekt> listaObiektow;

        public AdapterObiektow(Context context, List<Obiekt> listaObiektow) {
            this.listaObiektow = listaObiektow;
        }

        @NonNull
        @Override
        public AdapterObiektow.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.jedenobiekt, parent, false);
            return new AdapterObiektow.ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final AdapterObiektow.ViewHolder holder, final int position) {

            holder.textView_nazwa.setText(listaObiektow.get(position).getNazwa());
            holder.textView_adres.setText(listaObiektow.get(position).getAdres());
            holder.textView_opis.setText(listaObiektow.get(position).getOpis());

            // KLIKANIE W OBIEKT I ROZWIJANIE
            holder.view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    holder.expandable.toggle();
                }
            });


            // SPRAWDZANIE CZY USER MA JUZ TAKI OBIEKT NA LISCIE
            for (String userID : listaObiektow.get(position).getUzytkownicy()) {
                if (userID.equalsIgnoreCase(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
                    holder.checkBox_jestNaLiscie.setChecked(true);
                }
            }

            // AKCJA KLIKANIA W CHECKBOX
            holder.checkBox_jestNaLiscie.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    if (position < listaObiektow.size()) {
                        if (b) {
                            listaZaznaczonychObiektow.add(listaObiektow.get(position));
                        } else {
                            listaZaznaczonychObiektow.remove(listaObiektow.get(position));
                        }
                    }
                }
            });

        }

        @Override
        public int getItemCount() {
            return listaObiektow.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            ExpandableRelativeLayout expandable;
            TextView textView_nazwa;
            TextView textView_opis;
            TextView textView_adres;
            CheckBox checkBox_jestNaLiscie;
            View view;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                view = itemView;
                expandable = itemView.findViewById(R.id.expandable);
                textView_nazwa = itemView.findViewById(R.id.textView_nazwa);
                textView_opis = itemView.findViewById(R.id.textView_opis);
                textView_adres = itemView.findViewById(R.id.textView_adres);
                checkBox_jestNaLiscie = itemView.findViewById(R.id.checkBox_jestNaLiscie);
            }

        }
    }
}